<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>
		<?= $page_name ?>
		</h1>
		<ol class="breadcrumb">
			<li><a href="<?= base_url() ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="active"><?= $page_name ?></li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<div class="row">
			<!-- /.col -->
			<div class="col-md-12">
				<div class="box box-primary">
					<div class="box-header with-border">
						<!-- /.box-tools -->
					</div>
					<!-- /.box-header -->
					<div class="box-body ">
					    <div class="row">
					        <div class="col-md-3">
					        	<label>Kategori Surat</label>
					            <select class="form-control" id="kategori">
					            	<option value=""> Pilih </option>
									<?php
									$kategori_surat = $this->mymodel->selectWhere('m_kategori_surat',array('status'=>'ENABLE'));
									foreach($kategori_surat as $ks){
										?>
										<option value="<?=$ks['id']?>"><?=$ks['mkt_kategori']?></option>
										<?php
									}
									?>
								</select>
					        </div>
					        <div class="col-md-3">
					        	<button class="btn btn-primary" type="button" onclick="set_tables()" style="margin-top: 24px"><i class="fa fa-filter"></i></button>
					        </div>
					    </div>
						<br>
						<div id="load-table">
							<!-- /.table -->
						</div>
						<script type="text/javascript">
	function set_tables() {
      $('#load-table').html('<table class="table table-hover table-responsive table-condensed table-bordered table-striped listSurat" id="myTable" style="width: 100%;">'+
							'	<thead class="bg-navy">'+
							'		<tr>'+
							'			<th>No</th>'+
							'			<th>Tanggal</th>'+
							'			<th>Signer</th>'+
							'			<th>Nomor Surat</th>'+
							'			<th>Dikirimkan Kepada</th>'+
							'			<th>Perihal</th>'+
							'			<th>PIC & NO.Telp</th>'+
							'		</tr>'+
							'	</thead>'+
							'	<tbody>'+
							'	</tbody>'+
							'</table>');
      var url = '?kategori='+$('#kategori').val();
		loadtable(url);
    }

	function loadtable(url='') {

        var t = $("#myTable").dataTable({
        	// scrollX : true,
            initComplete: function() {
                var api = this.api();
                $('#mytable_filter input')
                        .off('.DT')
                        .on('keyup.DT', function(e) {
                            if (e.keyCode == 13) {
                                api.search(this.value).draw();
                    }
                });
            },
            oLanguage: {
                sProcessing: "loading..."
            },
            processing: true,
            serverSide: true,
    		stateSave: true,
    		"bDestroy": true,
            ajax: {"url": "<?= base_url('report/json') ?>"+url, "type": "POST"},
            data: {param1: 'value1'},
            columns: [
                {"data": "ad_id","orderable": false},
                {
                	"data": "ad_tanggalsurat",
                	render : function (data, type, row) {
            			var html = row['tanggal_surat'];
            			return html;
            		}
            	},
                {"data": "ad_tandatangan"},
                {
                	"data": "ad_nomorsurat",
                	render : function (data, type, row) {
            			var html = '<a href="#">'+row['ad_nomorsurat']+'</a>';
            			return html;
            		}
            	},
                {"data": "ad_dikirim"},
                {"data": "ad_perihal"},
                 {
                	"data": "ad_notelp",
                	render : function (data, type, row) {
            			var html = row['ad_pic']+'/'+row['ad_notelp'];
            			return html;
            		}
            	},
            ],
            order: [[1, 'asc']],
            rowCallback: function(row, data, iDisplayIndex) {
                var info = this.fnPagingInfo();
                var page = info.iPage;
                var length = info.iLength;
                var index = page * length + (iDisplayIndex + 1);
                $('td:eq(0)', row).html(index);
                $.ajax({
                	url : "<?=base_url()?>arsip_dokumen/getSonEncode/"+data['ad_id'],
                	success : function(view){
                		$('td:eq(3)', row).html('<a href="<?=base_url()?>arsip_dokumen/detail/'+view+'">'+data['ad_nomorsurat']+'</a>');
                	}
                });
            }
        });
    }
    set_tables();
</script>
						<!-- /.mail-box-messages -->
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /. box -->
			</div>
			<!-- /.col -->
		</div>
		<!-- /.row -->
	</section>
	<!-- /.content -->
</div>