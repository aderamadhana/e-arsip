<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Arsip_dokumen extends MY_Controller {
	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{
		$data['page_name'] = "List Surat";
		$data['view_menu'] = $this->view_menu();
		$this->template->load('template/template','arsip_dokumen/index',$data);
	}
	public function add($id='')
	{
		$data['page_name'] = "Tambah Permohonan Surat Masuk";
		$data['view_menu'] = $this->view_menu();
		$data['arsip'] = $this->mymodel->selectDataone('arsip_dokumen',array('ad_id'=>$id));

		$this->db->order_by('ad_id', 'desc');
		$data['lastid'] = $this->db->get('arsip_dokumen')->row_array();
		$this->template->load('template/template','arsip_dokumen/add',$data);
	}
	public function addSuratKeluar($id='')
	{
		$data['page_name'] = "Tambah Permohonan Surat Keluar";
		$data['view_menu'] = $this->view_menu();
		$data['arsip'] = $this->mymodel->selectDataone('arsip_dokumen',array('ad_id'=>$id));
		$this->template->load('template/template','arsip_dokumen/add-surat-keluar',$data);
	}
	public function view_menu()
	{
		$this->db->select('COUNT(*) as total');
		if ($this->session->userdata('role_slug')!='super_admin' && $this->session->userdata('role_slug')!='sekertaris') {
			$this->db->join('arsip_dokumen_log', 'arsip_dokumen_log.adl_id_arsip_dokumen = arsip_dokumen.ad_id AND adl_isaktif="1"', 'left');
			$this->db->join('arsip_dokumen_log_detail', 'arsip_dokumen_log_detail.adld_id_arsip_dokumen_log = arsip_dokumen_log.adl_id AND adld_id_penerima = "'.$this->session->userdata('id').'"');
		}
		$this->db->where('status', 'draft');
		$data['draft'] = $this->mymodel->selectDataone('arsip_dokumen',[]);

		$this->db->select('COUNT(*) as total');
		if ($this->session->userdata('role_slug')!='super_admin' && $this->session->userdata('role_slug')!='sekertaris') {
			$this->db->join('arsip_dokumen_log', 'arsip_dokumen_log.adl_id_arsip_dokumen = arsip_dokumen.ad_id AND adl_isaktif="1"', 'left');
			$this->db->join('arsip_dokumen_log_detail', 'arsip_dokumen_log_detail.adld_id_arsip_dokumen_log = arsip_dokumen_log.adl_id AND adld_id_penerima = "'.$this->session->userdata('id').'" AND adld_isread = "0"');
		}
		if ($this->session->userdata('role_slug')=='super_admin' && $this->session->userdata('role_slug')!='sekertaris') {
			$this->db->where('status', 'diajukan');
		} else {
			$this->db->where('status', 'didisposisikan');
		}
		$data['inbox'] = $this->mymodel->selectDataone('arsip_dokumen',[]);

		$this->db->select('COUNT(*) as total');
		if ($this->session->userdata('role_slug')!='super_admin' && $this->session->userdata('role_slug')!='sekertaris') {
			$this->db->join('arsip_dokumen_log', 'arsip_dokumen_log.adl_id_arsip_dokumen = arsip_dokumen.ad_id AND adl_isaktif="1"', 'left');
			$this->db->join('arsip_dokumen_log_detail', 'arsip_dokumen_log_detail.adld_id_arsip_dokumen_log = arsip_dokumen_log.adl_id AND adld_id_penerima = "'.$this->session->userdata('id').'"');
		}
		$this->db->where('status', 'void');
		$data['void'] = $this->mymodel->selectDataone('arsip_dokumen',[]);

		return $this->load->view('arsip_dokumen/menu', $data, TRUE);
	}
	public function saveArsip()
	{
		$datapost = $this->input->post();
		$dt = $datapost['dt'];
		$dt['created_at'] = date('Y-m-d H:i:s');
		$dt['created_by'] = $this->session->userdata('id');
		$dt['status'] = "diajukan";
		if(!empty($_FILES['file_tindak_lanjut']['name'])){
			$dt['ad_file_tindaklanjut'] = $this->upload_file_dir('file_tindak_lanjut','webfile/')['message']['dir'];
		}
		$this->db->update('arsip_dokumen', $dt,array('ad_id'=>$datapost['id']));
		$this->updateStatusArsipDokumen($datapost['id'],'diajukan','Diajukan Oleh Sekertaris');

		$this->mymodel->updateData('arsip_dokumen_log',array('adl_isaktif'=>0),array('adl_id_arsip_dokumen'=>$datapost['id']));
		$arrayinsertlog = array(
			'adl_id_arsip_dokumen' => $datapost['id'],
			'adl_isi_disposisi' => '-',
			'adl_status' => 'diajukan',
			'adl_waktu' => date('Y-m-d H:i:s'),
			'adl_isaktif' => 1,
		);
		$this->mymodel->insertData('arsip_dokumen_log',$arrayinsertlog);
		$idlog = $this->db->insert_id();

		$arrayinsertlogdetail = array(
			'adld_id_arsip_dokumen' => $datapost['id'],
			'adld_id_arsip_dokumen_log' => $idlog,
			'adld_id_pengirim' => $this->session->userdata('id'),
			'adld_id_penerima' => $this->session->userdata('id'),
			'adld_isread' => 1,
		);
		$this->mymodel->insertData('arsip_dokumen_log_detail',$arrayinsertlogdetail);
		$logdetail[] = $arrayinsertlogdetail;

		$this->mymodel->updateData('arsip_dokumen_log',array('adl_json_detail'=>json_encode($logdetail)),array('adl_id'=>$idlog));

		echo 'success';
	} 
	public function saveArsipSuratKeluar(){
		$datapost = $this->input->post();
		$dt = $datapost['dt'];
		$dt['created_at'] = date('Y-m-d H:i:s');
		$dt['created_by'] = $this->session->userdata('id');
		$dt['status'] = "selesai";
		$departemen = $this->mymodel->selectDataone('m_departemen',array('id'=>$dt['ad_departemen']));
		$dt['ad_kategorisurat_code'] = $departemen['code'];
		$dt['ad_kategorisurat'] = $departemen['nama'];
		// if(!empty($_FILES['file_tindak_lanjut']['name'])){
		// 	$dt['ad_file_tindaklanjut'] = $this->upload_file_dir('file_tindak_lanjut','webfile/')['message']['dir'];
		// }
		$this->db->update('arsip_dokumen', $dt,array('ad_id'=>$datapost['id']));
		// $this->updateStatusArsipDokumen($datapost['id'],'diajukan','Diajukan Oleh Sekertaris');

		// $this->mymodel->updateData('arsip_dokumen_log',array('adl_isaktif'=>0),array('adl_id_arsip_dokumen'=>$datapost['id']));
		// $arrayinsertlog = array(
		// 	'adl_id_arsip_dokumen' => $datapost['id'],
		// 	'adl_isi_disposisi' => '-',
		// 	'adl_status' => 'diajukan',
		// 	'adl_waktu' => date('Y-m-d H:i:s'),
		// 	'adl_isaktif' => 1,
		// );
		// $this->mymodel->insertData('arsip_dokumen_log',$arrayinsertlog);
		// $idlog = $this->db->insert_id();

		// $arrayinsertlogdetail = array(
		// 	'adld_id_arsip_dokumen' => $datapost['id'],
		// 	'adld_id_arsip_dokumen_log' => $idlog,
		// 	'adld_id_pengirim' => $this->session->userdata('id'),
		// 	'adld_id_penerima' => $this->session->userdata('id'),
		// 	'adld_isread' => 1,
		// );
		// $this->mymodel->insertData('arsip_dokumen_log_detail',$arrayinsertlogdetail);
		// $logdetail[] = $arrayinsertlogdetail;

		// $this->mymodel->updateData('arsip_dokumen_log',array('adl_json_detail'=>json_encode($logdetail)),array('adl_id'=>$idlog));

		echo 'success';
	}
	public function aksiTindakLanjut(){
		$dt = $this->input->post();
		$data = array(
			'ad_tindaklanjut'=>$dt['ad_tindaklanjut'],
			'status_message'=>'Telah Ditindak Lanjuti Oleh Officer',
			'status'=>'ditindaklanjuti'
		);
		if(!empty($_FILES['file_tindak_lanjut']['name'])){
			$data['ad_file_tindaklanjut'] = $this->upload_file_dir('file_tindak_lanjut','webfile/tindak-lanjut/')['message']['dir'];
		}
		$this->mymodel->updateData('arsip_dokumen',$data,array('ad_id'=>$dt['id']));

		$arrayinsertlog = array(
			'adl_id_arsip_dokumen' => $dt['id'],
			'adl_isi_disposisi' => '-',
			'adl_status' => 'Ditindak Lanjuti',
			'adl_waktu' => date('Y-m-d H:i:s'),
			'adl_isaktif' => 1,
		);
		$this->mymodel->insertData('arsip_dokumen_log',$arrayinsertlog);
		$idlog = $this->db->insert_id();

		$arrayinsertlogdetail = array(
			'adld_id_arsip_dokumen' => $dt['id'],
			'adld_id_arsip_dokumen_log' => $idlog,
			'adld_id_pengirim' => $this->session->userdata('id'),
			'adld_id_penerima' => $this->session->userdata('id'),
			'adld_isread' => 1,
		);
		$this->mymodel->insertData('arsip_dokumen_log_detail',$arrayinsertlogdetail);
		$logdetail[] = $arrayinsertlogdetail;
		$this->mymodel->updateData('arsip_dokumen_log',array('adl_json_detail'=>json_encode($logdetail)),array('adl_id'=>$idlog));

		redirect($_SERVER['HTTP_REFERER']);
	}
	public function getSonEncode($id){
		echo $this->template->sonEncode($id);
	}
	public function saveDraft()
	{
		$datapost = $this->input->post();
		$dt = $datapost['dt'];
		$cek = $this->mymodel->selectDataone('arsip_dokumen',array('ad_id'=>$datapost['id']));
		$dt['ad_kategorisurat_id'] = (int)$dt['ad_kategorisurat_id'];
		if($dt['ad_tipesurat'] == 'Surat Masuk'){
			$departemen = $this->mymodel->selectDataone('m_departemen',array('id'=>$dt['ad_kategorisurat_id']));
		}
		else{
			$departemen = $this->mymodel->selectDataone('m_departemen',array('id'=>$dt['ad_departemen']));
		}
		$dt['ad_kategorisurat_code'] = $departemen['code'];
		$dt['ad_kategorisurat'] = $departemen['nama'];

		if ($cek['ad_id']) {
			$this->db->update('arsip_dokumen', $dt,array('ad_id'=>$cek['ad_id']));
		} else {
			$dt['status'] = "draft";
			$dt['created_by'] = $this->session->userdata('id');
			$this->db->insert('arsip_dokumen', $dt);
		}
		// echo $this->db->last_query();
	}
	public function aksiVoid($id)
	{
		$this->updateStatusArsipDokumen($id,'void','Divoid Oleh '.$this->session->userdata('role_name'));
		$this->mymodel->updateData('arsip_dokumen_log',array('adl_isaktif'=>0),array('adl_id_arsip_dokumen'=>$id));
		$arrayinsertlog = array(
			'adl_id_arsip_dokumen' => $id,
			'adl_isi_disposisi' => '-',
			'adl_status' => 'void',
			'adl_waktu' => date('Y-m-d H:i:s'),
			'adl_isaktif' => 1,
		);
		$this->mymodel->insertData('arsip_dokumen_log',$arrayinsertlog);
		$idlog = $this->db->insert_id();

		$arrayinsertlogdetail = array(
			'adld_id_arsip_dokumen' => $id,
			'adld_id_arsip_dokumen_log' => $idlog,
			'adld_id_pengirim' => $this->session->userdata('id'),
			'adld_id_penerima' => $this->session->userdata('id'),
			'adld_isread' => 1,
		);
		$this->mymodel->insertData('arsip_dokumen_log_detail',$arrayinsertlogdetail);
		$logdetail[] = $arrayinsertlogdetail;
		redirect('arsip_dokumen?status=void');
		
	}
	public function getDataArsip()
	{
		$this->datatables->select('ad_id , ad_nomorsurat , ad_tanggalsurat , ad_instansipengirim , ad_bentukdokumen , ad_tipesurat , ad_duedate , arsip_dokumen.status , user.name as nama_pengirim,ad_tipesurat');
		$this->datatables->group_by('arsip_dokumen.ad_id');
		if (@$_GET['tipe']=='inbox') {
			$this->datatables->select('arsip_dokumen_log_detail.adld_isread');
				$this->datatables->join('arsip_dokumen_log', 'arsip_dokumen_log.adl_id_arsip_dokumen = arsip_dokumen.ad_id AND adl_isaktif="1"', 'left');
				$this->datatables->join('arsip_dokumen_log_detail', 'arsip_dokumen_log_detail.adld_id_arsip_dokumen_log = arsip_dokumen_log.adl_id AND adld_id_penerima = "'.$this->session->userdata('id').'" AND adld_id_penerima = "'.$this->session->userdata('id').'"');
		}
		else if($_GET['status'] == 'ditindaklanjuti'){
			$this->datatables->where('arsip_dokumen.status', $_GET['status']);
			if ($this->session->userdata('role_slug')=='super_admin' || $this->session->userdata('role_slug')=='sekertaris') {
				} else {
					$this->datatables->join('arsip_dokumen_log', 'arsip_dokumen_log.adl_id_arsip_dokumen = arsip_dokumen.ad_id', 'left');
					$this->datatables->join('arsip_dokumen_log_detail', 'arsip_dokumen_log_detail.adld_id_arsip_dokumen_log = arsip_dokumen_log.adl_id AND adld_id_penerima = "'.$this->session->userdata('id').'"');
				}
		}
		 else {
			if (@$_GET['status']) {
				$this->datatables->where('arsip_dokumen.status', $_GET['status']);
				if ($this->session->userdata('role_slug')=='super_admin' || $this->session->userdata('role_slug')=='sekertaris') {
				} else {
					$this->datatables->join('arsip_dokumen_log', 'arsip_dokumen_log.adl_id_arsip_dokumen = arsip_dokumen.ad_id', 'left');
					$this->datatables->join('arsip_dokumen_log_detail', 'arsip_dokumen_log_detail.adld_id_arsip_dokumen_log = arsip_dokumen_log.adl_id AND adld_id_pengirim = "'.$this->session->userdata('id').'"');
				}
			} else {
				if ($this->session->userdata('role_slug')=='super_admin' || $this->session->userdata('role_slug')=='sekertaris') {
					$this->datatables->where('arsip_dokumen.status', 'diajukan');
				} else {
					$this->datatables->join('arsip_dokumen_log', 'arsip_dokumen_log.adl_id_arsip_dokumen = arsip_dokumen.ad_id AND adl_isaktif="1"', 'left');
					$this->datatables->join('arsip_dokumen_log_detail', 'arsip_dokumen_log_detail.adld_id_arsip_dokumen_log = arsip_dokumen_log.adl_id AND adld_id_pengirim = "'.$this->session->userdata('id').'"');
					$this->datatables->where('arsip_dokumen.status', 'didisposisikan');
				}
			}
		}

		if (@$_GET['sifat']) {
			$this->datatables->where('ad_sifatsurat', $_GET['sifat']);
		}

		if (@$_GET['bentuk']) {
			$this->datatables->where('ad_bentukdokumen', $_GET['bentuk']);
		}

		if (@$_GET['kategori']) {
			$this->datatables->where('ad_kategorisurat', $_GET['kategori']);
		}

		if (@$_GET['duedate']) {
			$this->datatables->where('ad_duedate', $_GET['duedate']);
		}

		$this->db->join('user', 'user.id = arsip_dokumen.dari', 'left');
		$this->datatables->from('arsip_dokumen');
		echo $this->datatables->generate();
	}
	public function toDetailArsip($idArsip='')
	{
		$idArsip = $this->template->sonEncode($idArsip);
		redirect(base_url('arsip_dokumen/detail/'.$idArsip),'refresh');
	}
	public function detail($idArsip)
	{
		$idArsip = $this->template->sonDecode($idArsip);
		$this->mymodel->updateData('arsip_dokumen_log_detail',array('adld_isread'=>1),array('adld_id_arsip_dokumen'=>$idArsip,'adld_id_penerima'=>$this->session->userdata('id')));

		$data['page_name'] = "Detail Permohonan Surat";
		$data['data'] = $this->mmodel->selectWhere('arsip_dokumen',['ad_id' => $idArsip])->row();
		$data['view_menu'] = $this->view_menu();
		$this->template->load('template/template','arsip_dokumen/detail',$data);
	}

	public function uploadPDFWithQRCode()
	{
		$filename = uniqid().'-'.substr($_FILES['file']['name'], 0, strrpos($_FILES['file']['name'], "."));
		$fileupload = $this->upload_file_dir('file','webfile/',$filename);

		$return = [];
		if ($fileupload['response']) {
			$this->addQRCodeToPDF($fileupload['message']['dir']);
			$return = $this->uploadFileFromServerToCloud($fileupload['message']['dir']);
		}

		@unlink($fileupload['message']['dir']);
		echo $return;

	}

	public function addQRCodeToPDF($file)
	{
		require_once(APPPATH."third_party/fpdf/fpdf.php");
		require_once(APPPATH."third_party/fpdi/src/autoload.php");

		$this->db->select('ad_id');
		$this->db->order_by('ad_id', 'desc');
		$lastid = $this->mymodel->selectDataone('arsip_dokumen',[]);

		$link = base_url('arsip_dokumen/detail/'.$this->template->sonEncode($lastid['ad_id']+1).'?source=qrcode');
		$logo = 'http://101.50.3.204/e-arsip/assets/logo_bri.png';
		$content = file_get_contents('https://app.aotol.com/qr/api?qr_content='.$link.'&qr_logo='.$logo);
		file_put_contents('webfile/qrcode.jpg', $content);

		$pdf = new \setasign\Fpdi\Fpdi();
		$pdf->AddPage();

		//Set the source PDF file
		$pagecount = $pdf->setSourceFile(APPPATH."../".$file);
		//Import the first page of the file
		$tppl = $pdf->importPage(1);
		// //Use this page as template
		// // use the imported page and place it at point 20,30 with a width of 170 mm
		$pdf->useTemplate($tppl, -10, 20, 210);


		// #Print Hello World at the bottom of the page

		// //Select Arial italic 8
		$pdf->Image(base_url('webfile/qrcode.jpg'), 2, 275, 20, 20);
		for ($i=2; $i <=$pagecount; $i++) {
		    $pdf->AddPage();
		    $tplId = $pdf->importPage($i);
		    $pdf->useTemplate($tplId);
		    $pdf->Image(base_url('webfile/qrcode.jpg'), 2, 275, 20, 20);
		}
		$pdf->Output($file, "F");
	}
	public function test()
	{
		$this->db->select('ad_id');
		$this->db->order_by('ad_id', 'desc');
		$lastid = $this->mymodel->selectDataone('arsip_dokumen',[]);

		$link = base_url('arsip_dokumen/detail/'.$this->template->sonEncode(124124).'?source=qrcode');
		$logo = 'http://101.50.3.204/e-arsip/assets/logo_bri.png';
		$content = file_get_contents('https://app.aotol.com/qr/api?qr_content='.$link.'&qr_logo='.$logo);
		file_put_contents('webfile/qrcode.jpg', $content);

		// echo base_url('webfile/qrcode.png');
	}

	public function aksiDisposisi()
	{
		$post = $this->input->post();
		$this->mymodel->updateData('arsip_dokumen_log',array('adl_isaktif'=>0),array('adl_id_arsip_dokumen'=>$post['id']));
		$arrayinsertlog = array(
			'adl_id_arsip_dokumen' => $post['id'],
			'adl_isi_disposisi' => $post['isi_disposisi'],
			// 'adl_arahan_kepala_bagian' => $post['arahan_kepala_bagian'],
			'adl_status' => 'didisposisikan',
			'adl_waktu' => date('Y-m-d H:i:s'),
			'adl_isaktif' => 1,
		);
		$this->mymodel->insertData('arsip_dokumen_log',$arrayinsertlog);
		$idlog = $this->db->insert_id();

		$logdetail = [];
		for ($i=0; $i < count($post['to']) ; $i++) { 
			$arrayinsertlogdetail = array(
				'adld_id_arsip_dokumen' => $post['id'],
				'adld_id_arsip_dokumen_log' => $idlog,
				'adld_id_pengirim' => $this->session->userdata('id'),
				'adld_id_penerima' => $post['to'][$i],
				'adld_isread' => 0,
			);
			$this->mymodel->insertData('arsip_dokumen_log_detail',$arrayinsertlogdetail);
			$logdetail[] = $arrayinsertlogdetail;
		}

		if ($this->session->userdata('role_slug')=='super_admin') {
			$statusmessage = 'Didisposisikan Ke Kepala Divisi';
		} elseif ($this->session->userdata('role_slug')=='sekertaris') {
			$statusmessage = 'Didisposisikan Ke Kepala Divisi';
		} elseif ($this->session->userdata('role_slug')=='kepala_divisi') {
			$statusmessage = 'Didisposisikan Ke Kepala Departemen';
		} elseif ($this->session->userdata('role_slug')=='kepala_departemen' || $this->session->userdata('role_slug')=='officer') {
			$statusmessage = 'Didisposisikan Ke Team Leader';
		} elseif ($this->session->userdata('role_slug')=='team_leader') {
			$statusmessage = 'Didisposisikan Ke Officer';
		}
		$this->updateStatusArsipDokumen($post['id'],'didisposisikan',$statusmessage);
		redirect('arsip_dokumen/detail/'.$this->template->sonEncode($post['id']));
	}

	public function updateStatusArsipDokumen($idarsip,$status,$message)
	{
		$array = array(
			'status' => $status,
			'status_message' => $message,
			'dari' => $this->session->userdata('id'),
			'kirim_date' => date('Y-m-d H:i:s'),
		);
		$query = $this->mymodel->updateData('arsip_dokumen',$array,array('ad_id'=>$idarsip));
		return $query;
	}
}
/* End of file Home.php */
/* Location: ./application/controllers/Home.php */